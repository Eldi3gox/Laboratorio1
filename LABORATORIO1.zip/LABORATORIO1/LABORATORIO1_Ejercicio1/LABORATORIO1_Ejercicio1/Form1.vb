﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim v1 As Integer
        Dim v2 As Integer

        v1 = TextBox1.Text
        v2 = TextBox2.Text

        TextBox3.Text = v1 + v2
        TextBox4.Text = v1 - v2
        TextBox5.Text = v1 * v2
        TextBox6.Text = v1 / v2
    End Sub
End Class
