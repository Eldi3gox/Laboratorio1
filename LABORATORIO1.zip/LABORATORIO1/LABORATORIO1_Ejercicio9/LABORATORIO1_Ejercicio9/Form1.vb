﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim base As Single
        Dim altura As Single
        base = TextBox1.Text
        altura = TextBox2.Text

        TextBox3.Text = (base * altura) / 2
    End Sub
End Class
