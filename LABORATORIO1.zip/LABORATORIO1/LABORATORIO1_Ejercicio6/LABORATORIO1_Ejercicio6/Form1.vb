﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim hora As Integer

        hora = TextBox1.Text

        If (hora >= 12) Then
            Label2.Text = "Pm"
        ElseIf (hora < 12) Then
            Label2.Text = "am"
        End If
    End Sub
End Class
