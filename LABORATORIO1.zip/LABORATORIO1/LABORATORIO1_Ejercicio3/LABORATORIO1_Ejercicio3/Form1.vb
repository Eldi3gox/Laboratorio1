﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As Integer
        Dim b As Integer
        Dim c As Integer

        a = TextBox1.Text
        b = TextBox2.Text
        c = TextBox3.Text

        If (a > b) And (a > c) Then
            TextBox4.Text = a
        End If
        If (b > a) And (b > c) Then
            TextBox4.Text = b
        End If
        If (c > a) And (c > b) Then
            TextBox4.Text = c
        End If

    End Sub
End Class
