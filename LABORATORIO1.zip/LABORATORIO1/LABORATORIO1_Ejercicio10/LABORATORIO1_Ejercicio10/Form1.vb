﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a As Integer
        a = TextBox1.Text

        If (a Mod 5) Then
            MsgBox("No multiplo")
        Else
            MsgBox("Es multiplo")
        End If
    End Sub
End Class
