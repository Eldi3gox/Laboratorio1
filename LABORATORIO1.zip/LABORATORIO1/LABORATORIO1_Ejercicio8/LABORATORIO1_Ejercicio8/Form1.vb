﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim valor As Integer
        valor = TextBox1.Text

        If (valor = 0) Then
            TextBox2.Text = "nulo"
        ElseIf (valor < 0) Then
            TextBox2.Text = "Negativo"
        ElseIf (valor > 0) Then
            TextBox2.Text = "Positivo"
        End If
    End Sub
End Class
