﻿Public Class Persona
    'propiedades'
    Public nombre As String
    Public genero As String
    Public altura As String
    Public ciudad As String

    'Constructor'
    Public Sub New(nombre As String, genero As String, altura As String, ciudad As String)
        Me.nombre = nombre
        Me.genero = genero
        Me.altura = altura
        Me.ciudad = ciudad
    End Sub
    Public Sub New()

    End Sub

    'metodo' 
    Public Function comer(comida As String) As String
        Return "Nombre: " & Me.nombre & "
Género: " & Me.genero & "
Altura: " & Me.altura & "
Ciudad: " & Me.ciudad & "
Come: " & comida
    End Function
    Public Function duerme(horas As String) As String
        Return "Nombre: " & Me.nombre & "
Género: " & Me.genero & "
Altura: " & Me.altura & "
Ciudad: " & Me.ciudad & "
duerme: " & horas
    End Function
End Class
