﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim persona1 As Persona = New Persona()
        persona1.nombre = "Diego"
        persona1.genero = "Masculino"
        persona1.altura = "1.68 m"
        persona1.ciudad = "Mazatenango"

        RichTextBox1.Text = persona1.comer("Sopa de verduras")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim persona2 As Persona = New Persona()
        persona2.nombre = "Fernanda"
        persona2.genero = "Femenino"
        persona2.altura = "2 m"
        persona2.ciudad = "San Antonio"

        RichTextBox1.Text = persona2.duerme("10 horas")
    End Sub
End Class
