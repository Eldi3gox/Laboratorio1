﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim vgal As Integer
        Const v As Integer = 35

        vgal = TextBox1.Text

        TextBox3.Text = vgal * v

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim pagode As Integer

        pagode = TextBox4.Text

        TextBox5.Text = pagode - TextBox3.Text
    End Sub
End Class
