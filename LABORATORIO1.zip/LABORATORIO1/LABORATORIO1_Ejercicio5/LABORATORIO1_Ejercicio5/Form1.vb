﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (TextBox1.Text < 60) Then
            TextBox2.Text = "Reprobado"
        ElseIf (TextBox1.Text >= 60) And (TextBox1.Text < 70) Then
            TextBox2.Text = "Aprobado"
        ElseIf (TextBox1.Text >= 70) And (TextBox1.Text < 80) Then
            TextBox2.Text = "Notable"
        ElseIf (TextBox1.Text >= 80) And (TextBox1.Text < 90) Then
            TextBox2.Text = "Sobresaliente"
        ElseIf (TextBox1.Text >= 90) And (TextBox1.Text <= 100) Then
            TextBox2.Text = "Excelente"
        End If
    End Sub
End Class
