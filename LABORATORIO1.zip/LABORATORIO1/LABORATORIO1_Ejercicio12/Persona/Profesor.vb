﻿Public Class Profesor
    'Herencia'
    Inherits Persona
    'Atributo'
    Private _categoria As String
    Private _codigo As String

    'Propiedades'
    Public Property Categoria As String
        Get
            Return _categoria
        End Get
        Set(value As String)
            _categoria = value
        End Set
    End Property
    Public Property Codigo As String
        Get
            Return _codigo
        End Get
        Set(value As String)
            _codigo = value
        End Set
    End Property
    'Operacion/metodo'
    Public Sub generarcodigo()
        Me.Codigo = "Contratado" & Me.Apellidos.Substring(0, 3) & "22"
    End Sub
End Class
