﻿
Imports Persona

Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim empleado1 As Empleado = New Empleado()
        empleado1.Nombres = TextBox1.Text
        empleado1.Apellidos = TextBox3.Text
        empleado1.Documentos = TextBox2.Text
        empleado1.Tipos = ComboBox1.Text
        empleado1.TipoContrato = ComboBox2.Text
        empleado1.calcularSalario(3000)
        DataGridView1.Rows.Insert(0, empleado1.Tipos,
                                     empleado1.Nombres,
                                     empleado1.Apellidos,
                                     empleado1.Documentos,
                                     empleado1.Sueldo)
    End Sub
End Class
